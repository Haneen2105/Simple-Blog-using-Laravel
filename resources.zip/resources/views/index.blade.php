@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-9">
            <div class="d-flex justify-content-between">
            <h1>{{$user->username}} Blog</h1>
            <a href="/p/{{'create'}}">Upload New Post</a>

        </div>  
              <div>
                {{$user->posts->count()}} posts
          </div>
        </div>
    </div>
    <div class="d-flex justify-content-between">
    <div class="row pt-5">  
        

     @foreach($user->posts as $posts)
     <div class="row pt-5">
     <ul>
                        <li><a href="./p/{{ $posts->id }}">{{ ucfirst($posts->title) }}</a></li>
                    </ul>
     @endforeach

</div>
</div>
</div>
@endsection
