<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();
route::get('/p/create','App\Http\Controllers\postsController@create');
Route::get('/blog/{posts}', [App\Http\Controllers\postsController::class, 'show']);

route::get('/p','App\Http\Controllers\postsController@store');
//redirect to all posts
Route::get('/profile/{user}', [App\Http\Controllers\ProfileController::class, 'index'])->name('profile.show');

Route::get('/p/{posts}/edit', [\App\Http\Controllers\BlogPostController::class, 'edit']); //shows edit post form
Route::put('/p/{posts}/edit', [\App\Http\Controllers\BlogPostController::class, 'update']); //commits edited post to the database 
Route::delete('/p/{posts}', [\App\Http\Controllers\BlogPostController::class, 'destroy']); //deletes post from the database
