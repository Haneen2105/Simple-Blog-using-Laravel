

<?php $__env->startSection('content'); ?>
<div class="container">
    <strong><?php echo e($posts->title); ?></strong>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sa7er\haneen_blog\resources\views/show2.blade.php ENDPATH**/ ?>