<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-9">
            <div class="d-flex justify-content-between">
            <h1><?php echo e($user->username); ?> Blog</h1>
            <a href="/p/<?php echo e('create'); ?>">Upload New Post</a>

        </div>  
              <div>
                <?php echo e($user->posts->count()); ?> posts
          </div>
        </div>
    </div>
    <div class="d-flex justify-content-between">
    <div class="row pt-5">  
        

     <?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <div class="row pt-5">
     <ul>
                        <li><a href="./p/<?php echo e($posts->id); ?>"><?php echo e(ucfirst($posts->title)); ?></a></li>
                    </ul>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Sa7er\haneen_blog\resources\views/index.blade.php ENDPATH**/ ?>