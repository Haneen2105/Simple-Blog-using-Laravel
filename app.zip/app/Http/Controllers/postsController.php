<?php

namespace App\Http\controllers;

use Illuminate\Http\Request;

class postsController extends Controller
{
    public function __construct(){
        $this->middleware('auth');

    }
    public function create(){
        return view('create');
    }
    public function store(){
        $data= request()->validate([
            'title'=>'required',
            'body'=>'required',
        ]);

        auth()->user()->posts()->create($data);
        return redirect('/profile/' .auth()->user()->id);
    }
    public function show(posts $Posts)
{
	return $posts; //returns the fetched posts
}
public function edit(posts $blogPost)
{
	return view(‘edit’, [
‘post’ => $Posts,
]);
}
public function update(Request $request, posts $Posts)
    {
        $posts->update([
            'title' => $request->title,
            'body' => $request->body
        ]);

        return redirect('/profile/' .auth()->user()->id);
    }
    public function destroy(posts $posts)
    {
        $posts->delete();

        return redirect('/profile/' .auth()->user()->id);
    }

}
