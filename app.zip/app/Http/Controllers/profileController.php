<?php

namespace App\Http\Controllers;
Use App\Models\User;

use Illuminate\Http\Request;

class profileController extends Controller
{
    public function index($user)
    {
        $user=User::find($user);
        return view('index', ['user'=> $user]);
    }
}
